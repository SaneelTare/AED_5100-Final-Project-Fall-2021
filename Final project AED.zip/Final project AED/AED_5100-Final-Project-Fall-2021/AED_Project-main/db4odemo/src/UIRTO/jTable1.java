/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UIRTO;

/**
 *
 * @author sanee
 */
class jTable1 {

    jTable1(Object[][] data, String[] columnNames) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
// String[] columnNames = {"Buyer", "Seller", "Dealer" };
//       Object[][] data = {
//    {"Kathy", "Smith",     "Snowboarding"},
//    {"John", "Doe",     "Rowing"},
//    {"Sue", "Black",     "Knitting"},
//    {"Jane", "White",     "Speed reading"},
//    {"Joe", "Brown",     "Pool"}
//    }
//    
//JTable(Object[][] rowData, Object[] columnNames);
}
}
