package Business.Buyer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yashn
 */
public class Buyer {

    private String ManuFactureYear;
    private String Miles;
    private String Tire;
    private String AskPrice;

    public String getManuFactureYear() {
        return ManuFactureYear;
    }

    public void setManuFactureYear(String ManuFactureYear) {
        this.ManuFactureYear = ManuFactureYear;
    }

    public String getMiles() {
        return Miles;
    }

    public void setMiles(String Miles) {
        this.Miles = Miles;
    }

    public String getTire() {
        return Tire;
    }

    public void setTire(String Tire) {
        this.Tire = Tire;
    }

    public String getAskPrice() {
        return AskPrice;
    }

    public void setAskPrice(String AskPrice) {
        this.AskPrice = AskPrice;
    }

}
