
package Business.LoanComp;

/**
 *
 * @author saneel
 */
public class LoanAgent {
    private String AgentName ;

    public String getName() {
        return AgentName;
    }

    public void setName(String AgentName) {
        this.AgentName = AgentName;
}
}