/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.WorkQueue;

/**
 *
 * @author saneel
 */
public class BuyerCostWorkReq extends WorkRequest{
    private String MaintainCost;

    public String getMaintainCost() {
        return MaintainCost;
    }

    public void setMaintainCost(String MaintainCost) {
        this.MaintainCost = MaintainCost;
    }
    
}
